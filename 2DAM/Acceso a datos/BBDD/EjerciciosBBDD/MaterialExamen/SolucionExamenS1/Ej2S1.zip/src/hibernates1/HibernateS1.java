
package hibernates1;

import POJOS.Arma;
import POJOS.Escudo;
import POJOS.Personaje;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class HibernateS1 {
  public static void main(String[] args) {
      File f=new File("jugadas.txt");
      SessionFactory sf=HibernateUtil.sessionFactory();
      Session sesion=sf.openSession();
      Transaction t=sesion.beginTransaction();
      
      Query q=sesion.createQuery("FROM Personaje");
      List<Personaje> lista=q.list();
      int[]vidas=new int[lista.size()];
      System.out.println("TABLA PERSONAJE ANTES DE JUGAR");
      for(int i=0;i<lista.size();i++){
          System.out.println(lista.get(i).toString()); 
          vidas[lista.get(i).getId()-1]=lista.get(i).getVida();
      }   
      String cadena;
      String[] valor;
      Personaje pa,pd;
      Arma ar;
      Escudo es;
      
      try{
         FileReader fr=new FileReader(f);
         BufferedReader br=new BufferedReader(fr);
          
         cadena=br.readLine();
         while(cadena!=null){
            valor=cadena.split(",");
            pa=(Personaje)sesion.get(Personaje.class, Integer.parseInt(valor[0]));
            if(pa==null)
              System.out.println("El personaje atacante no existe, no se puede realizar la jugada");
            else{
                pd=(Personaje)sesion.get(Personaje.class, Integer.parseInt(valor[2]));
                if(pd==null)
                  System.out.println("El personaje defensor no existe, no se puede realizar la jugada");
                else{
                   ar=(Arma)sesion.get(Arma.class,Integer.parseInt(valor[1]));
                   if(ar==null)
                     System.out.println("El arma no existe, no se puede realizar la jugada");
                   else{
                      es=(Escudo)sesion.get(Escudo.class, Integer.parseInt(valor[3]));
                      if(es==null)
                        System.out.println("El escudo no existe, no se puede realizar la jugada");
                      else{
                         if(ar.getDano()<es.getDefensa()){
                            pa.setVida(pa.getVida()-(es.getDefensa()-ar.getDano()));
                            sesion.update(pa);
                         } else{
                             pd.setVida(pd.getVida()-(ar.getDano()-es.getDefensa()));
                             sesion.update(pd);
                         }
                      }
                   }
               }
            } 
            cadena=br.readLine();   
         }
         
          
        for(int i=0;i<lista.size();i++)  
          if(lista.get(i).getVida()<vidas[i]/2)
             sesion.delete(lista.get(i));
        
        t.commit();
        
        System.out.println("---------------------------------------------");  
        
        lista=q.list();  
        System.out.println("TABLA PERSONAJE DESPUES DE JUGAR");
        for(int i=0;i<lista.size();i++)
          System.out.println(lista.get(i).toString());  
        
        sesion.close();
        sf.close();
          
      }catch(Exception e){}
      
      
      
    }
    
}
