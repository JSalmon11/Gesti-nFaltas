package examens1;


import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ExamenS1 {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
       File f=new File("ventas.dat");
       double[] precio=new double[9];
       Class.forName("com.mysql.jdbc.Driver");
       
       String url="jdbc:mysql://localhost/Comercio";
       String user="root";
       String password="";
       Connection con=DriverManager.getConnection(url, user, password);
       Statement st=con.createStatement();
       ResultSet rs=st.executeQuery("select Codprod,Precio from Productos");
       while(rs.next()){
         precio[rs.getInt(1)/10-1]=rs.getDouble(2);
       }
       
       String instruccion="insert into Ventas values(?,?,?,?)";
       PreparedStatement ps1=con.prepareStatement(instruccion);
       instruccion="update ventas set vendido=vendido+?, ganancia=ganancia+? where CodVend=?";
       PreparedStatement ps2=con.prepareStatement(instruccion);
       
       PreparedStatement ps3=con.prepareStatement("select count(*) from Ventas where CodVend=?");
       
        System.out.println("TABLA VENTAS ANTES DE LA ACTUALIZACION");
        rs=st.executeQuery("select * from Ventas");
          
        while(rs.next()){
            System.out.println(rs.getString(1)+" "+rs.getInt(2)+" "+rs.getInt(3)+" "+rs.getDouble(4));
        }
       
       String Nvendedor;
       int Codprod,Unidades;
       try{
         FileInputStream fis=new FileInputStream(f);
         DataInputStream dis=new DataInputStream(fis);
         ResultSet rs3=null;  
         try{
            while(true){
                Nvendedor=dis.readUTF();
                Codprod=dis.readInt();
                Unidades=dis.readInt();
                ps3.setString(1, Nvendedor);
                rs3=ps3.executeQuery();
                rs3.next();
                if(rs3.getInt(1)==0){
                    System.out.println("El vendedor no existe, se va a dar de alta");
                    ps1.setString(1,Nvendedor);
                    ps1.setInt(2, Codprod);
                    ps1.setInt(3, Unidades);
                    ps1.setDouble(4, Unidades*precio[Codprod/10-1]);
                    ps1.executeUpdate();
                }else{
                    ps2.setInt(1, Unidades);
                    ps2.setDouble(2, Unidades*precio[Codprod/10-1]);
                    ps2.setString(3, Nvendedor);
                    ps2.executeUpdate();
                }
            } 
                 
         } catch(EOFException e){}
           
          dis.close();
          fis.close();
           
          System.out.println("TABLA VENTAS DESPUES DE LA ACTUALIZACION");
         rs=st.executeQuery("select * from Ventas");
          
          while(rs.next())
            System.out.println(rs.getString(1)+" "+rs.getInt(2)+" "+rs.getInt(3)+" "+rs.getDouble(4));
           
       }catch(Exception e){System.out.println(e);}
       
    }
    
}
